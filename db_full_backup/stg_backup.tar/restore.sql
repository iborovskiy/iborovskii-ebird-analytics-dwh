--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.8 (Ubuntu 14.8-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.8 (Ubuntu 14.8-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE stg;
--
-- Name: stg; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE stg WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE stg OWNER TO postgres;

\connect stg

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: stg_fact_family_comnames; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stg_fact_family_comnames (
    familycode character varying(20) NOT NULL,
    familylocale character varying(5) NOT NULL,
    familycomname character varying(100),
    familysciname character varying(100)
);


ALTER TABLE public.stg_fact_family_comnames OWNER TO postgres;

--
-- Name: stg_fact_locations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stg_fact_locations (
    locid character varying(20) NOT NULL,
    locname character varying(100),
    countryname character varying(50),
    subregionname character varying(50),
    lat real NOT NULL,
    lon real NOT NULL,
    latestobsdt timestamp without time zone NOT NULL,
    numspeciesalltime real
);


ALTER TABLE public.stg_fact_locations OWNER TO postgres;

--
-- Name: stg_fact_observation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stg_fact_observation (
    speciescode character varying(20) NOT NULL,
    sciname character varying(70) NOT NULL,
    locid character varying(20) NOT NULL,
    locname character varying(100),
    obsdt timestamp without time zone NOT NULL,
    howmany real,
    lat real NOT NULL,
    lon real NOT NULL,
    subid character varying(20) NOT NULL,
    comname character varying(70)
);


ALTER TABLE public.stg_fact_observation OWNER TO postgres;

--
-- Name: stg_fact_observation_tmp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stg_fact_observation_tmp (
    speciescode character varying(20),
    sciname character varying(70),
    locid character varying(20),
    locname character varying(100),
    obsdt timestamp without time zone,
    howmany real,
    lat real,
    lon real,
    subid character varying(20),
    comname character varying(70)
);


ALTER TABLE public.stg_fact_observation_tmp OWNER TO postgres;

--
-- Name: stg_fact_order_comnames; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stg_fact_order_comnames (
    ordersciname character varying(100) NOT NULL,
    orderlocale character varying(5) NOT NULL,
    ordercomname character varying(100)
);


ALTER TABLE public.stg_fact_order_comnames OWNER TO postgres;

--
-- Name: stg_fact_taxonomy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stg_fact_taxonomy (
    speciescode character varying(20) NOT NULL,
    sciname character varying(200),
    comname character varying(200),
    category character varying(20),
    ordersciname character varying(100),
    ordercomname character varying(100),
    familycode character varying(20),
    familycomname character varying(100),
    familysciname character varying(100)
);


ALTER TABLE public.stg_fact_taxonomy OWNER TO postgres;

--
-- Name: stg_fact_taxonomy_tmp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stg_fact_taxonomy_tmp (
    speciescode character varying(20) NOT NULL,
    sciname character varying(200),
    comname character varying(200),
    category character varying(20),
    ordersciname character varying(100),
    familycode character varying(20),
    familysciname character varying(100)
);


ALTER TABLE public.stg_fact_taxonomy_tmp OWNER TO postgres;

--
-- Data for Name: stg_fact_family_comnames; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stg_fact_family_comnames (familycode, familylocale, familycomname, familysciname) FROM stdin;
\.
COPY public.stg_fact_family_comnames (familycode, familylocale, familycomname, familysciname) FROM '$$PATH$$/3347.dat';

--
-- Data for Name: stg_fact_locations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stg_fact_locations (locid, locname, countryname, subregionname, lat, lon, latestobsdt, numspeciesalltime) FROM stdin;
\.
COPY public.stg_fact_locations (locid, locname, countryname, subregionname, lat, lon, latestobsdt, numspeciesalltime) FROM '$$PATH$$/3344.dat';

--
-- Data for Name: stg_fact_observation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stg_fact_observation (speciescode, sciname, locid, locname, obsdt, howmany, lat, lon, subid, comname) FROM stdin;
\.
COPY public.stg_fact_observation (speciescode, sciname, locid, locname, obsdt, howmany, lat, lon, subid, comname) FROM '$$PATH$$/3343.dat';

--
-- Data for Name: stg_fact_observation_tmp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stg_fact_observation_tmp (speciescode, sciname, locid, locname, obsdt, howmany, lat, lon, subid, comname) FROM stdin;
\.
COPY public.stg_fact_observation_tmp (speciescode, sciname, locid, locname, obsdt, howmany, lat, lon, subid, comname) FROM '$$PATH$$/3349.dat';

--
-- Data for Name: stg_fact_order_comnames; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stg_fact_order_comnames (ordersciname, orderlocale, ordercomname) FROM stdin;
\.
COPY public.stg_fact_order_comnames (ordersciname, orderlocale, ordercomname) FROM '$$PATH$$/3346.dat';

--
-- Data for Name: stg_fact_taxonomy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stg_fact_taxonomy (speciescode, sciname, comname, category, ordersciname, ordercomname, familycode, familycomname, familysciname) FROM stdin;
\.
COPY public.stg_fact_taxonomy (speciescode, sciname, comname, category, ordersciname, ordercomname, familycode, familycomname, familysciname) FROM '$$PATH$$/3345.dat';

--
-- Data for Name: stg_fact_taxonomy_tmp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stg_fact_taxonomy_tmp (speciescode, sciname, comname, category, ordersciname, familycode, familysciname) FROM stdin;
\.
COPY public.stg_fact_taxonomy_tmp (speciescode, sciname, comname, category, ordersciname, familycode, familysciname) FROM '$$PATH$$/3348.dat';

--
-- Name: stg_fact_family_comnames stg_fact_family_comnames_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stg_fact_family_comnames
    ADD CONSTRAINT stg_fact_family_comnames_pkey PRIMARY KEY (familycode, familylocale);


--
-- Name: stg_fact_locations stg_fact_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stg_fact_locations
    ADD CONSTRAINT stg_fact_locations_pkey PRIMARY KEY (locid);


--
-- Name: stg_fact_observation stg_fact_observation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stg_fact_observation
    ADD CONSTRAINT stg_fact_observation_pkey PRIMARY KEY (speciescode, subid);


--
-- Name: stg_fact_order_comnames stg_fact_order_comnames_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stg_fact_order_comnames
    ADD CONSTRAINT stg_fact_order_comnames_pkey PRIMARY KEY (ordersciname, orderlocale);


--
-- Name: stg_fact_taxonomy stg_fact_taxonomy_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stg_fact_taxonomy
    ADD CONSTRAINT stg_fact_taxonomy_pkey PRIMARY KEY (speciescode);


--
-- Name: stg_fact_taxonomy_tmp stg_fact_taxonomy_tmp_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stg_fact_taxonomy_tmp
    ADD CONSTRAINT stg_fact_taxonomy_tmp_pkey PRIMARY KEY (speciescode);


--
-- PostgreSQL database dump complete
--

