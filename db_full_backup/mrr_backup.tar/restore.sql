--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.8 (Ubuntu 14.8-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.8 (Ubuntu 14.8-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE mrr;
--
-- Name: mrr; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE mrr WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE mrr OWNER TO postgres;

\connect mrr

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: mrr_process_dictionaries(character varying, character varying, character varying, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.mrr_process_dictionaries(IN path_to_csv character varying, IN loc_filename character varying, IN coutries_filename character varying, IN subregions_filename character varying, IN taxonomy_filename character varying)
    LANGUAGE plpgsql
    AS $_$
DECLARE
-- declare variables here
BEGIN
	-- delete old dictionaries tables
	TRUNCATE TABLE mrr_fact_locations;
	TRUNCATE TABLE mrr_fact_countries;
	TRUNCATE TABLE mrr_fact_subnational;
	TRUNCATE TABLE mrr_fact_taxonomy;
	
	-- import new data from csv files
	EXECUTE format
	(
		$str$
			COPY mrr_fact_locations(locid, locname, countrycode, subnational1Code, lat, lon, latestObsDt, numSpeciesAllTime)
			FROM %L
			DELIMITER ','
			CSV HEADER
		$str$, path_to_csv || '/' || loc_filename
	);

	EXECUTE format
	(
		$str$
			COPY mrr_fact_countries(countrycode, countryname)
			FROM %L
			DELIMITER ','
			CSV HEADER
		$str$, path_to_csv || '/' || coutries_filename
	);

	EXECUTE format
	(
		$str$
			COPY mrr_fact_subnational(subnationalCode, subnationalName)
			FROM %L
			DELIMITER ','
			CSV HEADER
		$str$, path_to_csv || '/' || subregions_filename
	);

	EXECUTE format
	(
		$str$
			COPY mrr_fact_taxonomy(speciesCode, sciName, comName, category, orderSciName, familyCode, familySciName)
			FROM %L
			DELIMITER ','
			CSV HEADER
		$str$, path_to_csv || '/' || taxonomy_filename
	);
	
END;
$_$;


ALTER PROCEDURE public.mrr_process_dictionaries(IN path_to_csv character varying, IN loc_filename character varying, IN coutries_filename character varying, IN subregions_filename character varying, IN taxonomy_filename character varying) OWNER TO postgres;

--
-- Name: mrr_process_new_observations(character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.mrr_process_new_observations(IN path_to_csv character varying, IN obs_filename character varying)
    LANGUAGE plpgsql
    AS $_$
DECLARE
-- declare variables here
BEGIN	
	-- import new data from csv files into temporary table
	EXECUTE format
	(
		$str$
			COPY mrr_fact_recent_observation_tmp(speciescode, sciname, locid, locname, obsdt, howmany, lat, lon,
												 obsvalid, obsreviewed, locationprivate, subid, comname, exoticcategory)
			FROM %L
			DELIMITER ','
			CSV HEADER
		$str$, path_to_csv || '/' || obs_filename
	);

	-- copy new data from tmp table into target fact table
	INSERT INTO mrr_fact_recent_observation
    SELECT *
    FROM mrr_fact_recent_observation_tmp
    ON CONFLICT(speciesCode, subId) DO NOTHING;
					
	-- delete temporary table
	DELETE FROM mrr_fact_recent_observation_tmp;

END;
$_$;


ALTER PROCEDURE public.mrr_process_new_observations(IN path_to_csv character varying, IN obs_filename character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: mrr_fact_countries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrr_fact_countries (
    countrycode character varying(5) NOT NULL,
    countryname character varying(50) NOT NULL
);


ALTER TABLE public.mrr_fact_countries OWNER TO postgres;

--
-- Name: mrr_fact_locations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrr_fact_locations (
    locid character varying(20) NOT NULL,
    locname character varying(100),
    countrycode character varying(5),
    subnational1code character varying(10),
    lat real NOT NULL,
    lon real NOT NULL,
    latestobsdt timestamp without time zone NOT NULL,
    numspeciesalltime real
);


ALTER TABLE public.mrr_fact_locations OWNER TO postgres;

--
-- Name: mrr_fact_recent_observation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrr_fact_recent_observation (
    speciescode character varying(20) NOT NULL,
    sciname character varying(70) NOT NULL,
    locid character varying(20) NOT NULL,
    locname character varying(100),
    obsdt timestamp without time zone NOT NULL,
    howmany real,
    lat real NOT NULL,
    lon real NOT NULL,
    obsvalid boolean NOT NULL,
    obsreviewed boolean NOT NULL,
    locationprivate boolean NOT NULL,
    subid character varying(20) NOT NULL,
    exoticcategory character varying(2),
    comname character varying(70)
);


ALTER TABLE public.mrr_fact_recent_observation OWNER TO postgres;

--
-- Name: mrr_fact_recent_observation_tmp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrr_fact_recent_observation_tmp (
    speciescode character varying(20),
    sciname character varying(70),
    locid character varying(20),
    locname character varying(100),
    obsdt timestamp without time zone,
    howmany real,
    lat real,
    lon real,
    obsvalid boolean,
    obsreviewed boolean,
    locationprivate boolean,
    subid character varying(20),
    exoticcategory character varying(2),
    comname character varying(70)
);


ALTER TABLE public.mrr_fact_recent_observation_tmp OWNER TO postgres;

--
-- Name: mrr_fact_subnational; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrr_fact_subnational (
    subnationalcode character varying(10) NOT NULL,
    subnationalname character varying(50) NOT NULL
);


ALTER TABLE public.mrr_fact_subnational OWNER TO postgres;

--
-- Name: mrr_fact_taxonomy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrr_fact_taxonomy (
    speciescode character varying(20) NOT NULL,
    sciname character varying(200) NOT NULL,
    comname character varying(200),
    category character varying(20) NOT NULL,
    ordersciname character varying(100),
    familycode character varying(20),
    familysciname character varying(100)
);


ALTER TABLE public.mrr_fact_taxonomy OWNER TO postgres;

--
-- Name: mrr_fact_weather_observations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrr_fact_weather_observations (
    loc_id character varying(20) NOT NULL,
    obsdt date NOT NULL,
    tavg real,
    tmin real,
    tmax real,
    prcp real,
    snow real,
    wdir real,
    wspd real,
    wpgt real,
    pres real,
    tsun real,
    update_ts timestamp without time zone
);


ALTER TABLE public.mrr_fact_weather_observations OWNER TO postgres;

--
-- Data for Name: mrr_fact_countries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrr_fact_countries (countrycode, countryname) FROM stdin;
\.
COPY public.mrr_fact_countries (countrycode, countryname) FROM '$$PATH$$/3347.dat';

--
-- Data for Name: mrr_fact_locations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrr_fact_locations (locid, locname, countrycode, subnational1code, lat, lon, latestobsdt, numspeciesalltime) FROM stdin;
\.
COPY public.mrr_fact_locations (locid, locname, countrycode, subnational1code, lat, lon, latestobsdt, numspeciesalltime) FROM '$$PATH$$/3346.dat';

--
-- Data for Name: mrr_fact_recent_observation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrr_fact_recent_observation (speciescode, sciname, locid, locname, obsdt, howmany, lat, lon, obsvalid, obsreviewed, locationprivate, subid, exoticcategory, comname) FROM stdin;
\.
COPY public.mrr_fact_recent_observation (speciescode, sciname, locid, locname, obsdt, howmany, lat, lon, obsvalid, obsreviewed, locationprivate, subid, exoticcategory, comname) FROM '$$PATH$$/3345.dat';

--
-- Data for Name: mrr_fact_recent_observation_tmp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrr_fact_recent_observation_tmp (speciescode, sciname, locid, locname, obsdt, howmany, lat, lon, obsvalid, obsreviewed, locationprivate, subid, exoticcategory, comname) FROM stdin;
\.
COPY public.mrr_fact_recent_observation_tmp (speciescode, sciname, locid, locname, obsdt, howmany, lat, lon, obsvalid, obsreviewed, locationprivate, subid, exoticcategory, comname) FROM '$$PATH$$/3350.dat';

--
-- Data for Name: mrr_fact_subnational; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrr_fact_subnational (subnationalcode, subnationalname) FROM stdin;
\.
COPY public.mrr_fact_subnational (subnationalcode, subnationalname) FROM '$$PATH$$/3348.dat';

--
-- Data for Name: mrr_fact_taxonomy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrr_fact_taxonomy (speciescode, sciname, comname, category, ordersciname, familycode, familysciname) FROM stdin;
\.
COPY public.mrr_fact_taxonomy (speciescode, sciname, comname, category, ordersciname, familycode, familysciname) FROM '$$PATH$$/3349.dat';

--
-- Data for Name: mrr_fact_weather_observations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrr_fact_weather_observations (loc_id, obsdt, tavg, tmin, tmax, prcp, snow, wdir, wspd, wpgt, pres, tsun, update_ts) FROM stdin;
\.
COPY public.mrr_fact_weather_observations (loc_id, obsdt, tavg, tmin, tmax, prcp, snow, wdir, wspd, wpgt, pres, tsun, update_ts) FROM '$$PATH$$/3351.dat';

--
-- Name: mrr_fact_countries mrr_fact_countries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mrr_fact_countries
    ADD CONSTRAINT mrr_fact_countries_pkey PRIMARY KEY (countrycode);


--
-- Name: mrr_fact_locations mrr_fact_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mrr_fact_locations
    ADD CONSTRAINT mrr_fact_locations_pkey PRIMARY KEY (locid);


--
-- Name: mrr_fact_recent_observation mrr_fact_recent_observation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mrr_fact_recent_observation
    ADD CONSTRAINT mrr_fact_recent_observation_pkey PRIMARY KEY (speciescode, subid);


--
-- Name: mrr_fact_subnational mrr_fact_subnational_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mrr_fact_subnational
    ADD CONSTRAINT mrr_fact_subnational_pkey PRIMARY KEY (subnationalcode);


--
-- Name: mrr_fact_taxonomy mrr_fact_taxonomy_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mrr_fact_taxonomy
    ADD CONSTRAINT mrr_fact_taxonomy_pkey PRIMARY KEY (speciescode);


--
-- Name: mrr_fact_weather_observations mrr_fact_weather_observations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mrr_fact_weather_observations
    ADD CONSTRAINT mrr_fact_weather_observations_pkey PRIMARY KEY (loc_id, obsdt);


--
-- PostgreSQL database dump complete
--

