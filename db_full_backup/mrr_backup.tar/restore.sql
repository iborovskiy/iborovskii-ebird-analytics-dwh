--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.11 (Debian 13.11-0+deb11u1)
-- Dumped by pg_dump version 13.11 (Debian 13.11-0+deb11u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE mrr;
--
-- Name: mrr; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE mrr WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE mrr OWNER TO postgres;

\connect mrr

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: mrr_process_dictionaries(character varying, character varying, character varying, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.mrr_process_dictionaries(path_to_csv character varying, loc_filename character varying, coutries_filename character varying, subregions_filename character varying, taxonomy_filename character varying)
    LANGUAGE plpgsql
    AS $_$
DECLARE
-- declare variables here
BEGIN
	-- delete old dictionaries tables
	TRUNCATE TABLE mrr_fact_locations;
	TRUNCATE TABLE mrr_fact_countries;
	TRUNCATE TABLE mrr_fact_subnational;
	TRUNCATE TABLE mrr_fact_taxonomy;
	
	-- import new data from csv files
	EXECUTE format
	(
		$str$
			COPY mrr_fact_locations(locid, locname, countrycode, subnational1Code, lat, lon, latestObsDt, numSpeciesAllTime)
			FROM %L
			DELIMITER ','
			CSV HEADER
		$str$, path_to_csv || '/' || loc_filename
	);

	EXECUTE format
	(
		$str$
			COPY mrr_fact_countries(countrycode, countryname)
			FROM %L
			DELIMITER ','
			CSV HEADER
		$str$, path_to_csv || '/' || coutries_filename
	);

	EXECUTE format
	(
		$str$
			COPY mrr_fact_subnational(subnationalCode, subnationalName)
			FROM %L
			DELIMITER ','
			CSV HEADER
		$str$, path_to_csv || '/' || subregions_filename
	);

	EXECUTE format
	(
		$str$
			COPY mrr_fact_taxonomy(speciesCode, sciName, comName, category, orderSciName, familyCode, familySciName)
			FROM %L
			DELIMITER ','
			CSV HEADER
		$str$, path_to_csv || '/' || taxonomy_filename
	);
	
END;
$_$;


ALTER PROCEDURE public.mrr_process_dictionaries(path_to_csv character varying, loc_filename character varying, coutries_filename character varying, subregions_filename character varying, taxonomy_filename character varying) OWNER TO postgres;

--
-- Name: mrr_process_new_observations(character varying, character varying, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.mrr_process_new_observations(path_to_csv character varying, loc_filename character varying, cl_filename character varying, obs_filename character varying)
    LANGUAGE plpgsql
    AS $_$
DECLARE
-- declare variables here
BEGIN	
	-- import new data from csv files into temporary table
	EXECUTE format
	(
		$str$
			COPY mrr_fact_location_tmp(locId, countryCode, countryName, subnational1Name, subnational1Code,
                                		isHotspot, locName, lat, lng, hierarchicalName, obsFullDt)
			FROM %L
			DELIMITER ','
			CSV HEADER
		$str$, path_to_csv || '/' || loc_filename
	);
	
	EXECUTE format
	(
		$str$
			COPY mrr_fact_checklist_tmp(locId, subId, userDisplayName, numSpecies, obsFullDt)
			FROM %L
			DELIMITER ','
			CSV HEADER
		$str$, path_to_csv || '/' || cl_filename
	);
	
	EXECUTE format
	(
		$str$
			COPY mrr_fact_observation_tmp(speciesCode, obsDt, subId, projId, obsId, howMany, present)
			FROM %L
			DELIMITER ','
			CSV HEADER
		$str$, path_to_csv || '/' || obs_filename
	);

	-- copy new data from tmp table into target fact table
    INSERT INTO mrr_fact_location
    SELECT *
    FROM mrr_fact_location_tmp
    ON CONFLICT (locId) DO UPDATE
    SET countryCode = EXCLUDED.countryCode, countryName = EXCLUDED.countryName,
        subnational1Name = EXCLUDED.subnational1Name,
        subnational1Code = EXCLUDED.subnational1Code,
        isHotspot = EXCLUDED.isHotspot, locName = EXCLUDED.locName,
        lat = EXCLUDED.lat, lng = EXCLUDED.lng,
        hierarchicalName = EXCLUDED.hierarchicalName,
        obsFullDt = EXCLUDED.obsFullDt;
		
    INSERT INTO mrr_fact_checklist
    SELECT *
    FROM mrr_fact_checklist_tmp
    ON CONFLICT (subId) DO UPDATE
    SET locId = EXCLUDED.locId, userDisplayName = EXCLUDED.userDisplayName,
        numSpecies = EXCLUDED.numSpecies,
        obsFullDt = EXCLUDED.obsFullDt;
		
    INSERT INTO mrr_fact_observation
    SELECT *
    FROM mrr_fact_observation_tmp
    ON CONFLICT (obsId) DO UPDATE
    SET speciesCode = EXCLUDED.speciesCode, obsDt = EXCLUDED.obsDt,
        subId = EXCLUDED.subId,
        projId = EXCLUDED.projId,
        howMany = EXCLUDED.howMany,
        present = EXCLUDED.present;
					
	-- delete temporary table
	TRUNCATE TABLE mrr_fact_location_tmp;
	TRUNCATE TABLE mrr_fact_checklist_tmp;
	TRUNCATE TABLE mrr_fact_observation_tmp;

END;
$_$;


ALTER PROCEDURE public.mrr_process_new_observations(path_to_csv character varying, loc_filename character varying, cl_filename character varying, obs_filename character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: mrr_fact_checklist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrr_fact_checklist (
    locid character varying(20) NOT NULL,
    subid character varying(20) NOT NULL,
    userdisplayname character varying(100),
    numspecies integer,
    obsfulldt timestamp without time zone
);


ALTER TABLE public.mrr_fact_checklist OWNER TO postgres;

--
-- Name: mrr_fact_checklist_tmp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrr_fact_checklist_tmp (
    locid character varying(20),
    subid character varying(20),
    userdisplayname character varying(100),
    numspecies integer,
    obsfulldt timestamp without time zone
);


ALTER TABLE public.mrr_fact_checklist_tmp OWNER TO postgres;

--
-- Name: mrr_fact_countries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrr_fact_countries (
    countrycode character varying(5) NOT NULL,
    countryname character varying(50) NOT NULL
);


ALTER TABLE public.mrr_fact_countries OWNER TO postgres;

--
-- Name: mrr_fact_hotspots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrr_fact_hotspots (
    locid character varying(20) NOT NULL,
    locname character varying(100),
    countrycode character varying(5),
    subnational1code character varying(10),
    lat real NOT NULL,
    lon real NOT NULL,
    latestobsdt timestamp without time zone NOT NULL,
    numspeciesalltime real
);


ALTER TABLE public.mrr_fact_hotspots OWNER TO postgres;

--
-- Name: mrr_fact_location; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrr_fact_location (
    locid character varying(20) NOT NULL,
    countrycode character varying(5),
    countryname character varying(100),
    subnational1name character varying(100),
    subnational1code character varying(10),
    ishotspot boolean,
    locname character varying(100),
    lat real,
    lng real,
    hierarchicalname character varying(200),
    obsfulldt timestamp without time zone
);


ALTER TABLE public.mrr_fact_location OWNER TO postgres;

--
-- Name: mrr_fact_location_tmp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrr_fact_location_tmp (
    locid character varying(20),
    countrycode character varying(5),
    countryname character varying(100),
    subnational1name character varying(100),
    subnational1code character varying(10),
    ishotspot boolean,
    locname character varying(100),
    lat real,
    lng real,
    hierarchicalname character varying(200),
    obsfulldt timestamp without time zone
);


ALTER TABLE public.mrr_fact_location_tmp OWNER TO postgres;

--
-- Name: mrr_fact_observation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrr_fact_observation (
    speciescode character varying(20) NOT NULL,
    obsdt timestamp without time zone NOT NULL,
    subid character varying(20) NOT NULL,
    projid character varying(200) NOT NULL,
    obsid character varying(20) NOT NULL,
    howmany integer,
    present boolean
);


ALTER TABLE public.mrr_fact_observation OWNER TO postgres;

--
-- Name: mrr_fact_observation_tmp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrr_fact_observation_tmp (
    speciescode character varying(20),
    obsdt timestamp without time zone,
    subid character varying(20),
    projid character varying(200),
    obsid character varying(20),
    howmany integer,
    present boolean
);


ALTER TABLE public.mrr_fact_observation_tmp OWNER TO postgres;

--
-- Name: mrr_fact_subnational; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrr_fact_subnational (
    subnationalcode character varying(10) NOT NULL,
    subnationalname character varying(50) NOT NULL
);


ALTER TABLE public.mrr_fact_subnational OWNER TO postgres;

--
-- Name: mrr_fact_taxonomy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrr_fact_taxonomy (
    speciescode character varying(20) NOT NULL,
    sciname character varying(200) NOT NULL,
    comname character varying(200),
    category character varying(20) NOT NULL,
    ordersciname character varying(100),
    familycode character varying(20),
    familysciname character varying(100)
);


ALTER TABLE public.mrr_fact_taxonomy OWNER TO postgres;

--
-- Name: mrr_fact_weather_observations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrr_fact_weather_observations (
    loc_id character varying(20) NOT NULL,
    obsdt date NOT NULL,
    tavg real,
    tmin real,
    tmax real,
    prcp real,
    snow real,
    wdir real,
    wspd real,
    wpgt real,
    pres real,
    tsun real,
    update_ts timestamp without time zone
);


ALTER TABLE public.mrr_fact_weather_observations OWNER TO postgres;

--
-- Data for Name: mrr_fact_checklist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrr_fact_checklist (locid, subid, userdisplayname, numspecies, obsfulldt) FROM stdin;
\.
COPY public.mrr_fact_checklist (locid, subid, userdisplayname, numspecies, obsfulldt) FROM '$$PATH$$/3040.dat';

--
-- Data for Name: mrr_fact_checklist_tmp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrr_fact_checklist_tmp (locid, subid, userdisplayname, numspecies, obsfulldt) FROM stdin;
\.
COPY public.mrr_fact_checklist_tmp (locid, subid, userdisplayname, numspecies, obsfulldt) FROM '$$PATH$$/3041.dat';

--
-- Data for Name: mrr_fact_countries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrr_fact_countries (countrycode, countryname) FROM stdin;
\.
COPY public.mrr_fact_countries (countrycode, countryname) FROM '$$PATH$$/3042.dat';

--
-- Data for Name: mrr_fact_hotspots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrr_fact_hotspots (locid, locname, countrycode, subnational1code, lat, lon, latestobsdt, numspeciesalltime) FROM stdin;
\.
COPY public.mrr_fact_hotspots (locid, locname, countrycode, subnational1code, lat, lon, latestobsdt, numspeciesalltime) FROM '$$PATH$$/3043.dat';

--
-- Data for Name: mrr_fact_location; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrr_fact_location (locid, countrycode, countryname, subnational1name, subnational1code, ishotspot, locname, lat, lng, hierarchicalname, obsfulldt) FROM stdin;
\.
COPY public.mrr_fact_location (locid, countrycode, countryname, subnational1name, subnational1code, ishotspot, locname, lat, lng, hierarchicalname, obsfulldt) FROM '$$PATH$$/3044.dat';

--
-- Data for Name: mrr_fact_location_tmp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrr_fact_location_tmp (locid, countrycode, countryname, subnational1name, subnational1code, ishotspot, locname, lat, lng, hierarchicalname, obsfulldt) FROM stdin;
\.
COPY public.mrr_fact_location_tmp (locid, countrycode, countryname, subnational1name, subnational1code, ishotspot, locname, lat, lng, hierarchicalname, obsfulldt) FROM '$$PATH$$/3045.dat';

--
-- Data for Name: mrr_fact_observation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrr_fact_observation (speciescode, obsdt, subid, projid, obsid, howmany, present) FROM stdin;
\.
COPY public.mrr_fact_observation (speciescode, obsdt, subid, projid, obsid, howmany, present) FROM '$$PATH$$/3046.dat';

--
-- Data for Name: mrr_fact_observation_tmp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrr_fact_observation_tmp (speciescode, obsdt, subid, projid, obsid, howmany, present) FROM stdin;
\.
COPY public.mrr_fact_observation_tmp (speciescode, obsdt, subid, projid, obsid, howmany, present) FROM '$$PATH$$/3047.dat';

--
-- Data for Name: mrr_fact_subnational; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrr_fact_subnational (subnationalcode, subnationalname) FROM stdin;
\.
COPY public.mrr_fact_subnational (subnationalcode, subnationalname) FROM '$$PATH$$/3048.dat';

--
-- Data for Name: mrr_fact_taxonomy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrr_fact_taxonomy (speciescode, sciname, comname, category, ordersciname, familycode, familysciname) FROM stdin;
\.
COPY public.mrr_fact_taxonomy (speciescode, sciname, comname, category, ordersciname, familycode, familysciname) FROM '$$PATH$$/3049.dat';

--
-- Data for Name: mrr_fact_weather_observations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrr_fact_weather_observations (loc_id, obsdt, tavg, tmin, tmax, prcp, snow, wdir, wspd, wpgt, pres, tsun, update_ts) FROM stdin;
\.
COPY public.mrr_fact_weather_observations (loc_id, obsdt, tavg, tmin, tmax, prcp, snow, wdir, wspd, wpgt, pres, tsun, update_ts) FROM '$$PATH$$/3050.dat';

--
-- Name: mrr_fact_checklist mrr_fact_checklist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mrr_fact_checklist
    ADD CONSTRAINT mrr_fact_checklist_pkey PRIMARY KEY (subid);


--
-- Name: mrr_fact_countries mrr_fact_countries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mrr_fact_countries
    ADD CONSTRAINT mrr_fact_countries_pkey PRIMARY KEY (countrycode);


--
-- Name: mrr_fact_location mrr_fact_location_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mrr_fact_location
    ADD CONSTRAINT mrr_fact_location_pkey PRIMARY KEY (locid);


--
-- Name: mrr_fact_hotspots mrr_fact_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mrr_fact_hotspots
    ADD CONSTRAINT mrr_fact_locations_pkey PRIMARY KEY (locid);


--
-- Name: mrr_fact_observation mrr_fact_observation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mrr_fact_observation
    ADD CONSTRAINT mrr_fact_observation_pkey PRIMARY KEY (obsid);


--
-- Name: mrr_fact_subnational mrr_fact_subnational_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mrr_fact_subnational
    ADD CONSTRAINT mrr_fact_subnational_pkey PRIMARY KEY (subnationalcode);


--
-- Name: mrr_fact_taxonomy mrr_fact_taxonomy_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mrr_fact_taxonomy
    ADD CONSTRAINT mrr_fact_taxonomy_pkey PRIMARY KEY (speciescode);


--
-- Name: mrr_fact_weather_observations mrr_fact_weather_observations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mrr_fact_weather_observations
    ADD CONSTRAINT mrr_fact_weather_observations_pkey PRIMARY KEY (loc_id, obsdt);


--
-- PostgreSQL database dump complete
--

