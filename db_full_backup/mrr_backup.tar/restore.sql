--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.8 (Ubuntu 14.8-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.8 (Ubuntu 14.8-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE mrr;
--
-- Name: mrr; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE mrr WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE mrr OWNER TO postgres;

\connect mrr

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: mrr_fact_recent_observation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrr_fact_recent_observation (
    speciescode character varying(20) NOT NULL,
    sciname character varying(70) NOT NULL,
    locid character varying(20) NOT NULL,
    locname character varying(100),
    obsdt timestamp without time zone NOT NULL,
    howmany real,
    lat real NOT NULL,
    lon real NOT NULL,
    obsvalid boolean NOT NULL,
    obsreviewed boolean NOT NULL,
    locationprivate boolean NOT NULL,
    subid character varying(20) NOT NULL,
    exoticcategory character varying(2),
    comname character varying(70)
);


ALTER TABLE public.mrr_fact_recent_observation OWNER TO postgres;

--
-- Data for Name: mrr_fact_recent_observation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrr_fact_recent_observation (speciescode, sciname, locid, locname, obsdt, howmany, lat, lon, obsvalid, obsreviewed, locationprivate, subid, exoticcategory, comname) FROM stdin;
\.
COPY public.mrr_fact_recent_observation (speciescode, sciname, locid, locname, obsdt, howmany, lat, lon, obsvalid, obsreviewed, locationprivate, subid, exoticcategory, comname) FROM '$$PATH$$/3309.dat';

--
-- Name: mrr_fact_recent_observation mrr_fact_recent_observation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mrr_fact_recent_observation
    ADD CONSTRAINT mrr_fact_recent_observation_pkey PRIMARY KEY (speciescode, subid);


--
-- PostgreSQL database dump complete
--

