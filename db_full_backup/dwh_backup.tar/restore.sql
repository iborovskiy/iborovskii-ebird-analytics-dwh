--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.8 (Ubuntu 14.8-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.8 (Ubuntu 14.8-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dwh;
--
-- Name: dwh; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE dwh WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE dwh OWNER TO postgres;

\connect dwh

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: get_bird_species_by_loc(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_bird_species_by_loc(search_locid character varying) RETURNS TABLE(full_bird_species_names character varying)
    LANGUAGE plpgsql
    AS $$
declare
	-- variable declaration
	cur_species cursor(search_locid VARCHAR)
		for select d.comname, d.sciname
		from dwh_dim_species d
		where speciescode in (select distinct speciescode
						  from dwh_fact_observation
						  where locid = search_locid)
						  ORDER BY d.sciname;
	r record;
	--full_bird_species_names VARCHAR := '';
begin
	
	open cur_species(search_locid);
	loop
		fetch cur_species into r;
		exit when not found;
		full_bird_species_names := r.comname || ' (' || r.sciname || ')';
		return next;
	end loop;
	close cur_species;
end;
$$;


ALTER FUNCTION public.get_bird_species_by_loc(search_locid character varying) OWNER TO postgres;

--
-- Name: get_high_water_mark(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_high_water_mark(tbl_name character varying) RETURNS timestamp without time zone
    LANGUAGE plpgsql
    AS $$
DECLARE
	hwm TIMESTAMP;
BEGIN
	SELECT current_high_ts INTO STRICT hwm FROM high_water_mark WHERE table_id = tbl_name;
	RETURN hwm;
EXCEPTION
	WHEN no_data_found  THEN
		CALL write_log(NOW()::TIMESTAMP, 3, 'INTERNAL ERROR: Can''t get value of high watermark.');
	return NULL;
END;
$$;


ALTER FUNCTION public.get_high_water_mark(tbl_name character varying) OWNER TO postgres;

--
-- Name: process_new_row(character varying, character varying, character varying, character varying, timestamp without time zone, real, real, real, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.process_new_row(IN i_speciescode character varying, IN i_sciname character varying, IN i_locid character varying, IN i_locname character varying, IN i_obsdt timestamp without time zone, IN i_howmany real, IN i_lat real, IN i_lon real, IN i_subid character varying, IN i_comname character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
	new_high_water_mark TIMESTAMP;
BEGIN
	-- Insrt into dwh_dim_dt
	INSERT INTO dwh_dim_dt VALUES(i_obsdt, EXTRACT(day from i_obsdt), EXTRACT(month from i_obsdt),
								  TO_CHAR(i_obsdt, 'Month'), EXTRACT(year from i_obsdt),
								  EXTRACT(quarter from i_obsdt)) ON CONFLICT (obsdt) DO NOTHING;
								  
	-- Insrt into dwh_dim_location
	INSERT INTO dwh_dim_location VALUES(i_locid, i_locname, i_lat, i_lon)
                    ON CONFLICT (locid)
                    DO UPDATE
                    SET locname = EXCLUDED.locname, lat = EXCLUDED.lat, lon = EXCLUDED.lon;
					
	-- Insrt into dwh_dim_species
	INSERT INTO dwh_dim_species VALUES(i_speciescode, i_sciname, i_comname) 
                    ON CONFLICT (speciescode) DO NOTHING;
	
	-- Insrt into dwh_fact_observation
	INSERT INTO dwh_fact_observation VALUES(i_subid, i_speciescode, i_locid, i_obsdt, i_howmany);
	
	SELECT MAX(obsdt) INTO new_high_water_mark FROM dwh_fact_observation;
	
	INSERT INTO high_water_mark VALUES('dwh_fact_observation', new_high_water_mark)
	ON CONFLICT (table_id) DO UPDATE
	SET current_high_ts = EXCLUDED.current_high_ts;
	
EXCEPTION
	WHEN unique_violation THEN
		CALL write_log(NOW()::TIMESTAMP, 3, 'INTERNAL ERROR: Can''t process new source row into DWH target data model.');
END;
$$;


ALTER PROCEDURE public.process_new_row(IN i_speciescode character varying, IN i_sciname character varying, IN i_locid character varying, IN i_locname character varying, IN i_obsdt timestamp without time zone, IN i_howmany real, IN i_lat real, IN i_lon real, IN i_subid character varying, IN i_comname character varying) OWNER TO postgres;

--
-- Name: write_log(timestamp without time zone, integer, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.write_log(IN ts timestamp without time zone, IN lvl integer, IN msg character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
BEGIN
	INSERT INTO etl_log (ts, event_type, event_description) values (ts, lvl, msg);
END;
$$;


ALTER PROCEDURE public.write_log(IN ts timestamp without time zone, IN lvl integer, IN msg character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dwh_dim_dt; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dwh_dim_dt (
    obsdt timestamp without time zone NOT NULL,
    day integer NOT NULL,
    month integer NOT NULL,
    month_name character varying(20) NOT NULL,
    year integer NOT NULL,
    quarter integer NOT NULL
);


ALTER TABLE public.dwh_dim_dt OWNER TO postgres;

--
-- Name: dwh_dim_location; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dwh_dim_location (
    locid character varying(20) NOT NULL,
    locname character varying(100),
    lat real NOT NULL,
    lon real NOT NULL
);


ALTER TABLE public.dwh_dim_location OWNER TO postgres;

--
-- Name: dwh_dim_species; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dwh_dim_species (
    speciescode character varying(20) NOT NULL,
    sciname character varying(70) NOT NULL,
    comname character varying(70) NOT NULL
);


ALTER TABLE public.dwh_dim_species OWNER TO postgres;

--
-- Name: dwh_fact_observation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dwh_fact_observation (
    subid character varying(20) NOT NULL,
    speciescode character varying(20) NOT NULL,
    locid character varying(20) NOT NULL,
    obsdt timestamp without time zone NOT NULL,
    howmany real
);


ALTER TABLE public.dwh_fact_observation OWNER TO postgres;

--
-- Name: etl_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.etl_log (
    id integer NOT NULL,
    ts timestamp without time zone,
    event_type integer,
    event_description character varying(100)
);


ALTER TABLE public.etl_log OWNER TO postgres;

--
-- Name: etl_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.etl_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.etl_log_id_seq OWNER TO postgres;

--
-- Name: etl_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.etl_log_id_seq OWNED BY public.etl_log.id;


--
-- Name: etl_log_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.etl_log_view AS
 SELECT etl_log.ts,
        CASE
            WHEN (etl_log.event_type = 1) THEN 'INFO'::text
            WHEN (etl_log.event_type = 2) THEN 'WARNING'::text
            WHEN (etl_log.event_type = 3) THEN 'ERROR'::text
            ELSE NULL::text
        END AS msg_type,
    etl_log.event_description AS msg
   FROM public.etl_log;


ALTER TABLE public.etl_log_view OWNER TO postgres;

--
-- Name: high_water_mark; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.high_water_mark (
    table_id character varying(30) NOT NULL,
    current_high_ts timestamp without time zone
);


ALTER TABLE public.high_water_mark OWNER TO postgres;

--
-- Name: etl_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.etl_log ALTER COLUMN id SET DEFAULT nextval('public.etl_log_id_seq'::regclass);


--
-- Data for Name: dwh_dim_dt; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dwh_dim_dt (obsdt, day, month, month_name, year, quarter) FROM stdin;
\.
COPY public.dwh_dim_dt (obsdt, day, month, month_name, year, quarter) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: dwh_dim_location; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dwh_dim_location (locid, locname, lat, lon) FROM stdin;
\.
COPY public.dwh_dim_location (locid, locname, lat, lon) FROM '$$PATH$$/3357.dat';

--
-- Data for Name: dwh_dim_species; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dwh_dim_species (speciescode, sciname, comname) FROM stdin;
\.
COPY public.dwh_dim_species (speciescode, sciname, comname) FROM '$$PATH$$/3356.dat';

--
-- Data for Name: dwh_fact_observation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dwh_fact_observation (subid, speciescode, locid, obsdt, howmany) FROM stdin;
\.
COPY public.dwh_fact_observation (subid, speciescode, locid, obsdt, howmany) FROM '$$PATH$$/3359.dat';

--
-- Data for Name: etl_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.etl_log (id, ts, event_type, event_description) FROM stdin;
\.
COPY public.etl_log (id, ts, event_type, event_description) FROM '$$PATH$$/3354.dat';

--
-- Data for Name: high_water_mark; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.high_water_mark (table_id, current_high_ts) FROM stdin;
\.
COPY public.high_water_mark (table_id, current_high_ts) FROM '$$PATH$$/3355.dat';

--
-- Name: etl_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.etl_log_id_seq', 493, true);


--
-- Name: dwh_dim_dt dwh_dim_dt_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dwh_dim_dt
    ADD CONSTRAINT dwh_dim_dt_pkey PRIMARY KEY (obsdt);


--
-- Name: dwh_dim_location dwh_dim_location_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dwh_dim_location
    ADD CONSTRAINT dwh_dim_location_pkey PRIMARY KEY (locid);


--
-- Name: dwh_dim_species dwh_dim_species_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dwh_dim_species
    ADD CONSTRAINT dwh_dim_species_pkey PRIMARY KEY (speciescode);


--
-- Name: dwh_fact_observation dwh_fact_observation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dwh_fact_observation
    ADD CONSTRAINT dwh_fact_observation_pkey PRIMARY KEY (subid, speciescode);


--
-- Name: etl_log etl_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.etl_log
    ADD CONSTRAINT etl_log_pkey PRIMARY KEY (id);


--
-- Name: high_water_mark high_water_mark_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.high_water_mark
    ADD CONSTRAINT high_water_mark_pkey PRIMARY KEY (table_id);


--
-- Name: dwh_fact_observation dwh_fact_observation_locid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dwh_fact_observation
    ADD CONSTRAINT dwh_fact_observation_locid_fkey FOREIGN KEY (locid) REFERENCES public.dwh_dim_location(locid);


--
-- Name: dwh_fact_observation dwh_fact_observation_obsdt_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dwh_fact_observation
    ADD CONSTRAINT dwh_fact_observation_obsdt_fkey FOREIGN KEY (obsdt) REFERENCES public.dwh_dim_dt(obsdt);


--
-- Name: dwh_fact_observation dwh_fact_observation_speciescode_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dwh_fact_observation
    ADD CONSTRAINT dwh_fact_observation_speciescode_fkey FOREIGN KEY (speciescode) REFERENCES public.dwh_dim_species(speciescode);


--
-- PostgreSQL database dump complete
--

