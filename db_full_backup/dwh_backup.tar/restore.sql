--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.11 (Debian 13.11-0+deb11u1)
-- Dumped by pg_dump version 13.11 (Debian 13.11-0+deb11u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dwh;
--
-- Name: dwh; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE dwh WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE dwh OWNER TO postgres;

\connect dwh

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dwh_process_observations(character varying, character varying, character varying, character varying, character varying, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.dwh_process_observations(path_to_csv character varying, loc_filename character varying, cl_filename character varying, obs_filename character varying, hs_filename character varying, taxonomy_filename character varying, weather_filename character varying)
    LANGUAGE plpgsql
    AS $_$
DECLARE
-- declare variables here
BEGIN
	-- import csv files with new data sets from staging area
	
	-- import new observations into temporary fact table
	EXECUTE format
	(
		$str$
			COPY dwh_dim_location_tmp
			FROM %L
			DELIMITER ','
			CSV HEADER
		$str$, path_to_csv || '/' || loc_filename
	);

	EXECUTE format
	(
		$str$
			COPY dwh_dim_checklist_tmp
			FROM %L
			DELIMITER ','
			CSV HEADER
		$str$, path_to_csv || '/' || cl_filename
	);

	EXECUTE format
	(
		$str$
			COPY dwh_fact_observation_tmp
			FROM %L
			DELIMITER ','
			CSV HEADER
		$str$, path_to_csv || '/' || obs_filename
	);
	
	-- import new weather observations into temporary table
	EXECUTE format
	(
		$str$
			COPY dwh_fact_weather_observations_tmp
			FROM %L
			DELIMITER ','
			CSV HEADER
		$str$, path_to_csv || '/' || weather_filename
	);
	
	-- import new taxonomy dictionary into DWH
	TRUNCATE TABLE dwh_dim_species_details;
	
	EXECUTE format
	(
		$str$
			COPY dwh_dim_species_details
			FROM %L
			DELIMITER ','
			CSV HEADER
		$str$, path_to_csv || '/' || taxonomy_filename
	);
	
	-- import new public locations dictionary into DWH
	TRUNCATE TABLE dwh_dim_location_details;

	EXECUTE format
	(
		$str$
			COPY dwh_dim_location_details
			FROM %L
			DELIMITER ','
			CSV HEADER
		$str$, path_to_csv || '/' || hs_filename
	);

	-- create new data model for DWH
	
	-- create dimension table - dwh_dim_location (incremental update)
    INSERT INTO dwh_dim_location
    SELECT DISTINCT l.locid, l.locname, l.lat, l.lon, l.countryname, l.subregionname,
                    l.latestobsdt, d.numspeciesalltime
    FROM dwh_dim_location_tmp l
    LEFT JOIN dwh_dim_location_details d
    ON l.locid = d.locid
    ON CONFLICT (locid) DO UPDATE
    SET locname = EXCLUDED.locname, lat = EXCLUDED.lat, lon = EXCLUDED.lon,
        countryname = EXCLUDED.countryname, subRegionName = EXCLUDED.subRegionName,
        latestObsDt = EXCLUDED.latestObsDt, numSpeciesAllTime = EXCLUDED.numSpeciesAllTime;

	-- create dimension table - dwh_dim_dt (incremental update)
    INSERT INTO dwh_dim_dt
    SELECT DISTINCT obsdt, extract(day from obsdt), extract(month from obsdt),
                    TO_CHAR(obsdt, 'Month'), extract(year from obsdt), extract(quarter from obsdt)
    FROM dwh_fact_observation_tmp
    ON CONFLICT (obsdt) DO NOTHING;
	
	-- create dimension table - dwh_dim_checklist (incremental update)
	
    INSERT INTO dwh_dim_checklist
    SELECT DISTINCT c.locId, c.subId, c.userDisplayName, c.numSpecies, c.obsFullDt
    FROM dwh_dim_checklist_tmp c
    ON CONFLICT (subId) DO UPDATE
    SET locId = EXCLUDED.locId, userDisplayName = EXCLUDED.userDisplayName,
        numSpecies = EXCLUDED.numSpecies, obsFullDt = EXCLUDED.obsFullDt;

	-- create fact table - dwh_fact_observation (incremental update)
    INSERT INTO dwh_fact_observation
    SELECT o.subid, o.speciescode, c.locId, o.obsdt, o.howmany
    FROM dwh_fact_observation_tmp o
    LEFT JOIN dwh_dim_checklist c
    ON o.subid = c.subid
    ON CONFLICT (subId, speciescode) DO UPDATE
    SET locId = EXCLUDED.locId, obsdt = EXCLUDED.obsdt, howmany = EXCLUDED.howmany;
	
	-- update weather conditions for observations
    UPDATE dwh_fact_observation o
    SET tavg = w.tavg, tmin = w.tmin, tmax = w.tmax, prcp = w.prcp,
        snow = w.snow, wdir = w.wdir, wspd = w.wspd, wpgt = w.wpgt, 
        pres = w.pres, tsun = w.tsun
    FROM dwh_fact_weather_observations_tmp w
    WHERE o.locid = w.loc_id AND CAST(o.obsdt AS DATE) = w.obsdt;
		
	-- create dimension table - dwh_dim_species (full update not incremental)
	TRUNCATE TABLE dwh_dim_species;
	
    INSERT INTO dwh_dim_species
    SELECT DISTINCT o.speciescode, d.sciName, d.comName, d.category, d.orderSciName, d.orderComName,
                    d.familyCode, d.familyComName, d.familySciName
    FROM dwh_fact_observation o
    LEFT JOIN dwh_dim_species_details d
    ON o.speciescode = d.speciescode;
	
	-- update current high_water_mark on success of current DAG
	UPDATE high_water_mark
	SET current_high_ts = (SELECT MAX(obsdt) FROM dwh_fact_observation)
	WHERE table_id = 'dwh_fact_observation';

	UPDATE high_water_mark
	SET current_high_ts = (SELECT MAX(update_ts) FROM dwh_fact_weather_observations_tmp)
	WHERE table_id = 'mrr_fact_weather_observations' AND 
        (SELECT MAX(update_ts) FROM dwh_fact_weather_observations_tmp) IS NOT NULL;

	-- truncate temporary observation table
    TRUNCATE TABLE dwh_dim_checklist_tmp;
    TRUNCATE TABLE dwh_dim_location_tmp;
    TRUNCATE TABLE dwh_fact_observation_tmp;
    TRUNCATE TABLE dwh_fact_weather_observations_tmp;
		
END;
$_$;


ALTER PROCEDURE public.dwh_process_observations(path_to_csv character varying, loc_filename character varying, cl_filename character varying, obs_filename character varying, hs_filename character varying, taxonomy_filename character varying, weather_filename character varying) OWNER TO postgres;

--
-- Name: get_bird_species_by_loc(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_bird_species_by_loc(search_locid character varying) RETURNS TABLE(full_bird_species_names character varying)
    LANGUAGE plpgsql
    AS $$
declare
	-- variable declaration
	cur_species cursor(search_locid VARCHAR)
		for select d.comname, d.sciname
		from dwh_dim_species d
		where speciescode in (select distinct speciescode
						  from dwh_fact_observation
						  where locid = search_locid)
						  ORDER BY d.sciname;
	r record;
	--full_bird_species_names VARCHAR := '';
begin
	
	open cur_species(search_locid);
	loop
		fetch cur_species into r;
		exit when not found;
		full_bird_species_names := r.comname || ' (' || r.sciname || ')';
		return next;
	end loop;
	close cur_species;
end;
$$;


ALTER FUNCTION public.get_bird_species_by_loc(search_locid character varying) OWNER TO postgres;

--
-- Name: get_current_hwm(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_current_hwm(tbl_name character varying) RETURNS timestamp without time zone
    LANGUAGE plpgsql
    AS $$
DECLARE
	hwm TIMESTAMP;
BEGIN
	SELECT current_high_ts INTO STRICT hwm
	FROM high_water_mark
	WHERE table_id = tbl_name AND current_high_ts IS NOT NULL;
	
	RETURN hwm;
	
EXCEPTION
	WHEN no_data_found  THEN
		RETURN '2020-01-21 16:35';
END;
$$;


ALTER FUNCTION public.get_current_hwm(tbl_name character varying) OWNER TO postgres;

--
-- Name: process_new_row(character varying, character varying, character varying, character varying, timestamp without time zone, real, real, real, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.process_new_row(i_speciescode character varying, i_sciname character varying, i_locid character varying, i_locname character varying, i_obsdt timestamp without time zone, i_howmany real, i_lat real, i_lon real, i_subid character varying, i_comname character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
	new_high_water_mark TIMESTAMP;
BEGIN
	-- Insrt into dwh_dim_dt
	INSERT INTO dwh_dim_dt VALUES(i_obsdt, EXTRACT(day from i_obsdt), EXTRACT(month from i_obsdt),
								  TO_CHAR(i_obsdt, 'Month'), EXTRACT(year from i_obsdt),
								  EXTRACT(quarter from i_obsdt))
	ON CONFLICT (obsdt) DO NOTHING;
								  
	-- Insrt into dwh_dim_location
	INSERT INTO dwh_dim_location VALUES(i_locid, i_locname, i_lat, i_lon)
                    ON CONFLICT (locid)
                    DO UPDATE
                    SET locname = EXCLUDED.locname, lat = EXCLUDED.lat, lon = EXCLUDED.lon;
					
	-- Insrt into dwh_dim_species
	INSERT INTO dwh_dim_species VALUES(i_speciescode, i_sciname, i_comname) 
                    ON CONFLICT (speciescode) DO NOTHING;
	
	-- Insrt into dwh_fact_observation
	INSERT INTO dwh_fact_observation VALUES(i_subid, i_speciescode, i_locid, i_obsdt, i_howmany);
	
	-- update current high_water_mark on success
	UPDATE high_water_mark
	SET current_high_ts = (SELECT MAX(obsdt) FROM dwh_fact_observation)
	WHERE table_id = 'dwh_fact_observation';
	
EXCEPTION
	WHEN unique_violation THEN
		CALL write_log(NOW()::TIMESTAMP, 3, 'INTERNAL ERROR: Can''t process new source row into DWH target data model.');
END;
$$;


ALTER PROCEDURE public.process_new_row(i_speciescode character varying, i_sciname character varying, i_locid character varying, i_locname character varying, i_obsdt timestamp without time zone, i_howmany real, i_lat real, i_lon real, i_subid character varying, i_comname character varying) OWNER TO postgres;

--
-- Name: write_log(timestamp without time zone, integer, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.write_log(ts timestamp without time zone, lvl integer, msg character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
BEGIN
	INSERT INTO etl_log (ts, event_type, event_description) values (ts, lvl, msg);
END;
$$;


ALTER PROCEDURE public.write_log(ts timestamp without time zone, lvl integer, msg character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dwh_dim_checklist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dwh_dim_checklist (
    locid character varying(20) NOT NULL,
    subid character varying(20) NOT NULL,
    userdisplayname character varying(100),
    numspecies integer,
    obsfulldt timestamp without time zone
);


ALTER TABLE public.dwh_dim_checklist OWNER TO postgres;

--
-- Name: dwh_dim_checklist_tmp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dwh_dim_checklist_tmp (
    locid character varying(20) NOT NULL,
    subid character varying(20) NOT NULL,
    userdisplayname character varying(100),
    numspecies integer,
    obsfulldt timestamp without time zone
);


ALTER TABLE public.dwh_dim_checklist_tmp OWNER TO postgres;

--
-- Name: dwh_dim_dt; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dwh_dim_dt (
    obsdt timestamp without time zone NOT NULL,
    day integer NOT NULL,
    month integer NOT NULL,
    month_name character varying(20) NOT NULL,
    year integer NOT NULL,
    quarter integer NOT NULL
);


ALTER TABLE public.dwh_dim_dt OWNER TO postgres;

--
-- Name: dwh_dim_location; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dwh_dim_location (
    locid character varying(20) NOT NULL,
    locname character varying(100),
    lat real NOT NULL,
    lon real NOT NULL,
    countryname character varying(50),
    subregionname character varying(50),
    latestobsdt timestamp without time zone,
    numspeciesalltime real
);


ALTER TABLE public.dwh_dim_location OWNER TO postgres;

--
-- Name: dwh_dim_location_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dwh_dim_location_details (
    locid character varying(20) NOT NULL,
    locname character varying(100),
    countryname character varying(50),
    subregionname character varying(50),
    lat real NOT NULL,
    lon real NOT NULL,
    latestobsdt timestamp without time zone,
    numspeciesalltime real
);


ALTER TABLE public.dwh_dim_location_details OWNER TO postgres;

--
-- Name: dwh_dim_location_tmp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dwh_dim_location_tmp (
    locid character varying(20) NOT NULL,
    locname character varying(100),
    lat real NOT NULL,
    lon real NOT NULL,
    countryname character varying(50),
    subregionname character varying(50),
    latestobsdt timestamp without time zone,
    numspeciesalltime real
);


ALTER TABLE public.dwh_dim_location_tmp OWNER TO postgres;

--
-- Name: dwh_dim_species; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dwh_dim_species (
    speciescode character varying(20) NOT NULL,
    sciname character varying(70) NOT NULL,
    comname character varying(70) NOT NULL,
    category character varying(20),
    "orderSciName" character varying(100),
    "orderComName" character varying(100),
    "familyCode" character varying(20),
    "familyComName" character varying(100),
    "familySciName" character varying(100)
);


ALTER TABLE public.dwh_dim_species OWNER TO postgres;

--
-- Name: dwh_dim_species_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dwh_dim_species_details (
    speciescode character varying(20) NOT NULL,
    sciname character varying(200) NOT NULL,
    comname character varying(200),
    category character varying(20),
    ordersciname character varying(100),
    ordercomname character varying(100),
    familycode character varying(20),
    familycomname character varying(100),
    familysciname character varying(100)
);


ALTER TABLE public.dwh_dim_species_details OWNER TO postgres;

--
-- Name: dwh_fact_observation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dwh_fact_observation (
    subid character varying(20) NOT NULL,
    speciescode character varying(20) NOT NULL,
    locid character varying(20) NOT NULL,
    obsdt timestamp without time zone NOT NULL,
    howmany real,
    tavg real,
    tmin real,
    tmax real,
    prcp real,
    snow real,
    wdir real,
    wspd real,
    wpgt real,
    pres real,
    tsun real
);


ALTER TABLE public.dwh_fact_observation OWNER TO postgres;

--
-- Name: dwh_fact_observation_tmp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dwh_fact_observation_tmp (
    speciescode character varying(20) NOT NULL,
    obsdt timestamp without time zone NOT NULL,
    subid character varying(20) NOT NULL,
    obsid character varying(20) NOT NULL,
    howmany integer
);


ALTER TABLE public.dwh_fact_observation_tmp OWNER TO postgres;

--
-- Name: dwh_fact_weather_observations_tmp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dwh_fact_weather_observations_tmp (
    loc_id character varying(20) NOT NULL,
    obsdt date NOT NULL,
    tavg real,
    tmin real,
    tmax real,
    prcp real,
    snow real,
    wdir real,
    wspd real,
    wpgt real,
    pres real,
    tsun real,
    update_ts timestamp without time zone
);


ALTER TABLE public.dwh_fact_weather_observations_tmp OWNER TO postgres;

--
-- Name: etl_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.etl_log (
    id integer NOT NULL,
    ts timestamp without time zone,
    event_type integer,
    event_description character varying(200)
);


ALTER TABLE public.etl_log OWNER TO postgres;

--
-- Name: etl_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.etl_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.etl_log_id_seq OWNER TO postgres;

--
-- Name: etl_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.etl_log_id_seq OWNED BY public.etl_log.id;


--
-- Name: etl_log_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.etl_log_view AS
 SELECT etl_log.ts,
        CASE
            WHEN (etl_log.event_type = 1) THEN 'INFO'::text
            WHEN (etl_log.event_type = 2) THEN 'WARNING'::text
            WHEN (etl_log.event_type = 3) THEN 'ERROR'::text
            ELSE NULL::text
        END AS msg_type,
    etl_log.event_description AS msg
   FROM public.etl_log;


ALTER TABLE public.etl_log_view OWNER TO postgres;

--
-- Name: high_water_mark; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.high_water_mark (
    table_id character varying(30) NOT NULL,
    current_high_ts timestamp without time zone
);


ALTER TABLE public.high_water_mark OWNER TO postgres;

--
-- Name: etl_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.etl_log ALTER COLUMN id SET DEFAULT nextval('public.etl_log_id_seq'::regclass);


--
-- Data for Name: dwh_dim_checklist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dwh_dim_checklist (locid, subid, userdisplayname, numspecies, obsfulldt) FROM stdin;
\.
COPY public.dwh_dim_checklist (locid, subid, userdisplayname, numspecies, obsfulldt) FROM '$$PATH$$/3063.dat';

--
-- Data for Name: dwh_dim_checklist_tmp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dwh_dim_checklist_tmp (locid, subid, userdisplayname, numspecies, obsfulldt) FROM stdin;
\.
COPY public.dwh_dim_checklist_tmp (locid, subid, userdisplayname, numspecies, obsfulldt) FROM '$$PATH$$/3064.dat';

--
-- Data for Name: dwh_dim_dt; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dwh_dim_dt (obsdt, day, month, month_name, year, quarter) FROM stdin;
\.
COPY public.dwh_dim_dt (obsdt, day, month, month_name, year, quarter) FROM '$$PATH$$/3065.dat';

--
-- Data for Name: dwh_dim_location; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dwh_dim_location (locid, locname, lat, lon, countryname, subregionname, latestobsdt, numspeciesalltime) FROM stdin;
\.
COPY public.dwh_dim_location (locid, locname, lat, lon, countryname, subregionname, latestobsdt, numspeciesalltime) FROM '$$PATH$$/3066.dat';

--
-- Data for Name: dwh_dim_location_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dwh_dim_location_details (locid, locname, countryname, subregionname, lat, lon, latestobsdt, numspeciesalltime) FROM stdin;
\.
COPY public.dwh_dim_location_details (locid, locname, countryname, subregionname, lat, lon, latestobsdt, numspeciesalltime) FROM '$$PATH$$/3067.dat';

--
-- Data for Name: dwh_dim_location_tmp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dwh_dim_location_tmp (locid, locname, lat, lon, countryname, subregionname, latestobsdt, numspeciesalltime) FROM stdin;
\.
COPY public.dwh_dim_location_tmp (locid, locname, lat, lon, countryname, subregionname, latestobsdt, numspeciesalltime) FROM '$$PATH$$/3068.dat';

--
-- Data for Name: dwh_dim_species; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dwh_dim_species (speciescode, sciname, comname, category, "orderSciName", "orderComName", "familyCode", "familyComName", "familySciName") FROM stdin;
\.
COPY public.dwh_dim_species (speciescode, sciname, comname, category, "orderSciName", "orderComName", "familyCode", "familyComName", "familySciName") FROM '$$PATH$$/3069.dat';

--
-- Data for Name: dwh_dim_species_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dwh_dim_species_details (speciescode, sciname, comname, category, ordersciname, ordercomname, familycode, familycomname, familysciname) FROM stdin;
\.
COPY public.dwh_dim_species_details (speciescode, sciname, comname, category, ordersciname, ordercomname, familycode, familycomname, familysciname) FROM '$$PATH$$/3070.dat';

--
-- Data for Name: dwh_fact_observation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dwh_fact_observation (subid, speciescode, locid, obsdt, howmany, tavg, tmin, tmax, prcp, snow, wdir, wspd, wpgt, pres, tsun) FROM stdin;
\.
COPY public.dwh_fact_observation (subid, speciescode, locid, obsdt, howmany, tavg, tmin, tmax, prcp, snow, wdir, wspd, wpgt, pres, tsun) FROM '$$PATH$$/3071.dat';

--
-- Data for Name: dwh_fact_observation_tmp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dwh_fact_observation_tmp (speciescode, obsdt, subid, obsid, howmany) FROM stdin;
\.
COPY public.dwh_fact_observation_tmp (speciescode, obsdt, subid, obsid, howmany) FROM '$$PATH$$/3072.dat';

--
-- Data for Name: dwh_fact_weather_observations_tmp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dwh_fact_weather_observations_tmp (loc_id, obsdt, tavg, tmin, tmax, prcp, snow, wdir, wspd, wpgt, pres, tsun, update_ts) FROM stdin;
\.
COPY public.dwh_fact_weather_observations_tmp (loc_id, obsdt, tavg, tmin, tmax, prcp, snow, wdir, wspd, wpgt, pres, tsun, update_ts) FROM '$$PATH$$/3073.dat';

--
-- Data for Name: etl_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.etl_log (id, ts, event_type, event_description) FROM stdin;
\.
COPY public.etl_log (id, ts, event_type, event_description) FROM '$$PATH$$/3074.dat';

--
-- Data for Name: high_water_mark; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.high_water_mark (table_id, current_high_ts) FROM stdin;
\.
COPY public.high_water_mark (table_id, current_high_ts) FROM '$$PATH$$/3076.dat';

--
-- Name: etl_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.etl_log_id_seq', 1520, true);


--
-- Name: dwh_dim_checklist dwh_dim_checklist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dwh_dim_checklist
    ADD CONSTRAINT dwh_dim_checklist_pkey PRIMARY KEY (subid);


--
-- Name: dwh_dim_dt dwh_dim_dt_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dwh_dim_dt
    ADD CONSTRAINT dwh_dim_dt_pkey PRIMARY KEY (obsdt);


--
-- Name: dwh_dim_location dwh_dim_location_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dwh_dim_location
    ADD CONSTRAINT dwh_dim_location_pkey PRIMARY KEY (locid);


--
-- Name: dwh_dim_species dwh_dim_species_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dwh_dim_species
    ADD CONSTRAINT dwh_dim_species_pkey PRIMARY KEY (speciescode);


--
-- Name: dwh_dim_location_details dwh_fact_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dwh_dim_location_details
    ADD CONSTRAINT dwh_fact_locations_pkey PRIMARY KEY (locid);


--
-- Name: dwh_fact_observation dwh_fact_observation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dwh_fact_observation
    ADD CONSTRAINT dwh_fact_observation_pkey PRIMARY KEY (subid, speciescode);


--
-- Name: dwh_dim_species_details dwh_fact_taxonomy_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dwh_dim_species_details
    ADD CONSTRAINT dwh_fact_taxonomy_pkey PRIMARY KEY (speciescode);


--
-- Name: dwh_fact_weather_observations_tmp dwh_fact_weather_observations_tmp_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dwh_fact_weather_observations_tmp
    ADD CONSTRAINT dwh_fact_weather_observations_tmp_pkey PRIMARY KEY (loc_id, obsdt);


--
-- Name: etl_log etl_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.etl_log
    ADD CONSTRAINT etl_log_pkey PRIMARY KEY (id);


--
-- Name: high_water_mark high_water_mark_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.high_water_mark
    ADD CONSTRAINT high_water_mark_pkey PRIMARY KEY (table_id);


--
-- Name: dwh_fact_observation dwh_fact_observation_obsdt_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dwh_fact_observation
    ADD CONSTRAINT dwh_fact_observation_obsdt_fkey FOREIGN KEY (obsdt) REFERENCES public.dwh_dim_dt(obsdt);


--
-- PostgreSQL database dump complete
--

